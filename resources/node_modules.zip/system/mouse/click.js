"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const hmc_win32_1 = __importDefault(require("hmc-win32"));
const config = {
    name: 'mouse.click',
    displayName: '鼠标点击',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '在当前鼠标位置执行左键点击，支持延时',
    inputs: {
        time: {
            name: 'time',
            value: '',
            display: '',
            type: 'number',
            addConfig: {
                label: '延迟时间（毫秒）',
                placeholder: '请输入延迟时间',
                required: false,
                type: 'string'
            }
        }
    },
    outputs: {}
};
exports.config = config;
const impl = async function ({ time }) {
    time = time || 100;
    hmc_win32_1.default.leftClick(time); // 执行鼠标左键点击
};
exports.impl = impl;
