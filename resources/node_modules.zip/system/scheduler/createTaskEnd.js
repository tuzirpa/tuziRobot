"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: "scheduler.createTaskEnd",
    icon: "icon-task-create",
    displayName: "创建任务结束标记",
    comment: "创建任务结束标记",
    isControlEnd: true,
    inputs: {},
    outputs: {},
    async toCode() {
        return `});`;
    },
};
const impl = async function () { };
exports.impl = impl;
