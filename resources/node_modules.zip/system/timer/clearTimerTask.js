"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: "timer.closeTimerTask",
    icon: "icon-web-create",
    displayName: "清除定时任务",
    comment: "清除定时任务${timerTask}",
    inputs: {
        timerTask: {
            name: "timerTask",
            value: "",
            display: "",
            type: "number",
            addConfig: {
                label: "定时任务",
                placeholder: "定时任务",
                type: "variable",
                filtersType: "timer.timerTask",
                required: true,
                autoComplete: true,
            },
        },
    },
    outputs: {},
};
const impl = async function ({ timerTask }) {
    if (timerTask) {
        clearInterval(timerTask);
    }
};
exports.impl = impl;
