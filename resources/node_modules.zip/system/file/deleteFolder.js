"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
exports.config = {
    name: 'file.deleteFolder',
    sort: 2,
    displayName: '删除本地文件夹',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '删除本地文件夹${folderPath}',
    inputs: {
        folderPath: {
            name: 'folderPath',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                required: true,
                label: '文件夹路径',
                placeholder: '请输入文件夹路径',
                type: 'filePath',
                openDirectory: true
            }
        }
    },
    outputs: {}
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ folderPath }) {
        function deleteFolderRecursive(folderPath) {
            if (fs_1.default.existsSync(folderPath)) {
                fs_1.default.readdirSync(folderPath).forEach((file, index) => {
                    const curPath = path_1.default.join(folderPath, file);
                    if (fs_1.default.lstatSync(curPath).isDirectory()) {
                        // 递归删除文件夹
                        deleteFolderRecursive(curPath);
                    }
                    else {
                        // 删除文件
                        fs_1.default.unlinkSync(curPath);
                    }
                });
                fs_1.default.rmdirSync(folderPath); // 删除空文件夹
                console.log(`Successfully deleted ${folderPath}`);
            }
        }
        deleteFolderRecursive(folderPath);
    });
};
exports.impl = impl;
