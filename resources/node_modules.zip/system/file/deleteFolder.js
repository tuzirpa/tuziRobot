"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
exports.config = {
    name: 'file.deleteFolder',
    sort: 2,
    displayName: '删除本地文件夹',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '删除本地文件夹${folderPath}',
    inputs: {
        folderPath: {
            name: 'folderPath',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                required: true,
                label: '文件夹路径',
                placeholder: '请输入文件夹路径',
                type: 'filePath',
                openDirectory: true
            }
        }
    },
    outputs: {}
};
const impl = async function ({ folderPath }) {
    function deleteFolderRecursive(folderPath) {
        if (fs_1.default.existsSync(folderPath)) {
            fs_1.default.readdirSync(folderPath).forEach((file, index) => {
                const curPath = path_1.default.join(folderPath, file);
                if (fs_1.default.lstatSync(curPath).isDirectory()) {
                    // 递归删除文件夹
                    deleteFolderRecursive(curPath);
                }
                else {
                    // 删除文件
                    fs_1.default.unlinkSync(curPath);
                }
            });
            fs_1.default.rmdirSync(folderPath); // 删除空文件夹
            console.log(`删除成功: ${folderPath}`);
        }
    }
    deleteFolderRecursive(folderPath);
};
exports.impl = impl;
