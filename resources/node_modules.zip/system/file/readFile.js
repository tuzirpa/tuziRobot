"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
exports.config = {
    name: 'file.readFile',
    sort: 2,
    displayName: '读取文本文件',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '读取文本文件${filePath},并将内容赋值给${content}变量',
    inputs: {
        filePath: {
            name: 'filePath',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                required: true,
                placeholder: '请填写文件路径',
                label: '文件路径',
                defaultValue: '',
                type: 'filePath'
            }
        }
    },
    outputs: {
        content: {
            name: '',
            display: '文本',
            type: 'string',
            addConfig: {
                required: true,
                label: '文件内容',
                defaultValue: '文件内容',
                type: 'variable'
            }
        }
    }
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ filePath }) {
        if (!fs_1.default.existsSync(path_1.default.resolve(filePath)))
            throw new Error('文件不存在');
        return { content: fs_1.default.readFileSync(path_1.default.resolve(filePath), 'utf-8') };
    });
};
exports.impl = impl;
