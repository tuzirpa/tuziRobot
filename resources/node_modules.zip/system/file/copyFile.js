"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
exports.config = {
    name: 'file.copyFile',
    sort: 2,
    displayName: '复制文件',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '将文件${sourcePath}复制到${targetPath}',
    inputs: {
        sourcePath: {
            name: 'sourcePath',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                required: true,
                label: '源文件路径',
                placeholder: '请选择要复制的文件',
                type: 'filePath',
                openDirectory: false
            }
        },
        targetPath: {
            name: 'targetPath',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                required: true,
                label: '目标路径',
                placeholder: '请选择复制到的位置',
                type: 'filePath',
                openDirectory: true
            }
        },
        isCovered: {
            name: 'isCovered',
            value: '',
            type: 'boolean',
            addConfig: {
                label: '存在时是否覆盖',
                type: 'boolean',
                defaultValue: false,
                tip: '目标文件存在时是否覆盖'
            }
        }
    },
    outputs: {}
};
const impl = async function ({ sourcePath, targetPath, isCovered }) {
    if (!fs_1.default.existsSync(sourcePath)) {
        throw new Error('源文件不存在');
    }
    // 确保目标目录存在
    const targetDir = path_1.default.dirname(targetPath);
    if (!fs_1.default.existsSync(targetDir)) {
        fs_1.default.mkdirSync(targetDir, { recursive: true });
    }
    // 如果目标文件已存在且不覆盖，则修改文件名
    if (!isCovered && fs_1.default.existsSync(targetPath)) {
        const parsedPath = path_1.default.parse(targetPath);
        const newName = parsedPath.name + '_' + new Date().getTime() + parsedPath.ext;
        targetPath = path_1.default.join(parsedPath.dir, newName);
    }
    // 复制文件
    fs_1.default.copyFileSync(sourcePath, targetPath);
    console.log(`文件已成功复制到: ${targetPath}`);
};
exports.impl = impl;
