"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
exports.config = {
    name: 'file.rename',
    sort: 2,
    displayName: '重命名文件或目录',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '将文件或目录${filePath} 重命名为 ${newName}',
    inputs: {
        filePath: {
            name: 'filePath',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                required: true,
                placeholder: '请填写文件路径',
                label: '文件路径',
                defaultValue: '',
                type: 'filePath'
            }
        },
        newName: {
            name: 'newName',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                required: true,
                placeholder: '请填写新名称，如果重复，会覆盖原文件',
                label: '新名称',
                defaultValue: '',
                type: 'string'
            }
        }
    },
    outputs: {}
};
const impl = async function ({ filePath, newName }) {
    if (!fs_1.default.existsSync(path_1.default.resolve(filePath)))
        throw new Error('文件或目录不存在');
    newName = newName.trim();
    let newPath = newName;
    if (!newPath.includes('/')) {
        newPath = path_1.default.join(path_1.default.dirname(filePath), newName);
    }
    return fs_1.default.renameSync(path_1.default.resolve(filePath), path_1.default.resolve(newPath));
};
exports.impl = impl;
