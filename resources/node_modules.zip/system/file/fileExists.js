"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
exports.config = {
    name: 'file.exists',
    sort: 2,
    displayName: '文件是否存在',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '检查文件${filePath}是否存在,并将结果赋值给${exists}变量',
    inputs: {
        filePath: {
            name: 'filePath',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                required: true,
                placeholder: '请填写文件路径',
                label: '文件路径',
                defaultValue: '',
                type: 'filePath'
            }
        }
    },
    outputs: {
        exists: {
            name: '',
            display: '是否存在',
            type: 'boolean',
            addConfig: {
                required: true,
                label: '文件是否存在',
                defaultValue: 'false',
                type: 'variable'
            }
        }
    }
};
const impl = async function ({ filePath }) {
    const fullPath = path_1.default.resolve(filePath);
    const exists = fs_1.default.existsSync(fullPath);
    return { exists };
};
exports.impl = impl;
