"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
exports.config = {
    name: 'file.move',
    sort: 2,
    displayName: '移动文件或目录',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '将文件或目录${filePath} 移动到 ${newPath}',
    inputs: {
        filePath: {
            name: 'filePath',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                required: true,
                placeholder: '请填写文件路径',
                label: '文件路径',
                defaultValue: '',
                type: 'filePath'
            }
        },
        newPath: {
            name: 'newPath',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                required: true,
                placeholder: '请填写新文件路径/新目录路径，如果重复，会覆盖原文件',
                label: '新文件路径/新目录路径',
                defaultValue: '',
                type: 'string'
            }
        }
    },
    outputs: {}
};
const impl = async function ({ filePath, newPath }) {
    if (!fs_1.default.existsSync(path_1.default.resolve(filePath)))
        throw new Error('文件或目录不存在');
    return fs_1.default.renameSync(path_1.default.resolve(filePath), path_1.default.resolve(newPath));
};
exports.impl = impl;
