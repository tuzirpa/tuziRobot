"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
exports.config = {
    name: 'file.writeFile',
    sort: 2,
    displayName: '写入文件',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '将内容${content}写入文件${fileName}，存放目录${dir}',
    inputs: {
        content: {
            name: 'content',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                required: true,
                label: '写入内容',
                type: 'variable'
            }
        },
        fileName: {
            name: 'fileName',
            value: '',
            type: 'string',
            addConfig: {
                label: '文件名',
                placeholder: '请填写文件名',
                type: 'string',
                defaultValue: '',
                tip: '请填写文件名'
            }
        },
        dir: {
            name: 'dir',
            value: '',
            type: 'string',
            addConfig: {
                label: '文件存放目录',
                placeholder: '请选择文件存放目录',
                type: 'filePath',
                defaultValue: '',
                openDirectory: true,
                tip: '文件存放目录'
            }
        },
        isCovered: {
            name: 'isCovered',
            value: '',
            type: 'boolean',
            addConfig: {
                label: '存在时文件是否覆盖',
                type: 'boolean',
                defaultValue: false,
                tip: '存在时文件是否覆盖'
            }
        }
    },
    outputs: {}
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ content, fileName, dir, isCovered }) {
        if (!fs_1.default.existsSync(dir)) {
            fs_1.default.mkdirSync(dir, { recursive: true });
        }
        let filePath = path_1.default.join(dir, fileName);
        if (!isCovered && fs_1.default.existsSync(filePath)) {
            const parsedPath = path_1.default.parse(filePath);
            const newName = parsedPath.name + '_' + new Date().getTime() + parsedPath.ext;
            filePath = path_1.default.join(parsedPath.dir, newName);
        }
        fs_1.default.writeFileSync(filePath, content, 'utf8');
        console.log(`文件${filePath}写入成功`);
    });
};
exports.impl = impl;
