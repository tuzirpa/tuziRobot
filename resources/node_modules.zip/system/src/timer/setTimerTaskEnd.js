"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: "web.setOneTimerTaskEnd",
    icon: "icon-web-create",
    displayName: "定时器结束标记",
    comment: "定时器结束标记",
    isControlEnd: true,
    inputs: {},
    outputs: {},
    async toCode() {
        return `});`;
    },
};
const impl = async function () { };
exports.impl = impl;
