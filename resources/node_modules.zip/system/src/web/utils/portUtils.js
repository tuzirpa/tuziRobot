"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.nextPort = nextPort;
exports.getAvailablePort = getAvailablePort;
exports.checkPort = checkPort;
const node_net_1 = require("node:net");
function nextPort(port) {
    return port + 1;
}
async function getAvailablePort(port = 3000) {
    if (port < 1 || port > 65535) {
        throw new Error('无可用的端口');
    }
    const _port = await checkPort(port);
    if (_port) {
        return _port;
    }
    else {
        console.debug(`端口 ${port} 被占用，尝试下一个...`);
        return getAvailablePort(nextPort(port));
    }
}
function checkPort(port) {
    return new Promise((resolve, _reject) => {
        // 启动个服务，使用指定端口
        const server = (0, node_net_1.createServer)(() => { });
        // 即使服务器正在监听，但它不会阻止程序退出
        server.unref();
        function onListen() {
            server.close();
            resolve(port);
        }
        server.once('listening', onListen);
        server.on('error', (_e) => {
            resolve(false);
        });
        server.listen(port, '127.0.0.1');
    });
}
