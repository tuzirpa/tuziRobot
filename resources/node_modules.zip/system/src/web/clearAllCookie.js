"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'web.clearAllCookie',
    icon: 'icon-web-create',
    displayName: '清除所有cookie',
    comment: '在页面${browserPage}中清理所有的cookie',
    inputs: {
        browserPage: {
            name: 'browserPage',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                required: true,
                label: '标签页对象',
                placeholder: '选择标签页对象',
                type: 'variable',
                filtersType: 'web.page',
                autoComplete: true
            }
        }
    },
    outputs: {}
};
const impl = async function ({ browserPage }) {
    let cookies = await browserPage.cookies();
    await Promise.all(cookies.map(async (cookie) => {
        await browserPage.deleteCookie(cookie);
    }));
};
exports.impl = impl;
