"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const config = {
    name: 'web.elementClick',
    sort: 2,
    displayName: '点击元素',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '点击${element}',
    inputs: {
        element: {
            name: 'element',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                required: true,
                label: '元素对象',
                type: 'variable',
                filtersType: 'web.Element',
                autoComplete: true
            }
        }
    },
    outputs: {}
};
exports.config = config;
const impl = async function ({ element }) {
    await element.click();
};
exports.impl = impl;
