"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'web.closeBrowser',
    displayName: '关闭浏览器',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '关闭浏览器 ${browser}',
    inputs: {
        browser: {
            name: 'browser',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                label: '浏览器对象',
                type: 'variable',
                filtersType: 'web.browser',
                autoComplete: true
            }
        }
    },
    outputs: {}
};
const impl = async function ({ browser }) {
    await browser.close();
    console.log('Browser closed');
};
exports.impl = impl;
