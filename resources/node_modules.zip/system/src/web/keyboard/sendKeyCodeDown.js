"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const keyCodeMap_1 = require("../utils/keyCodeMap");
const config = {
    name: 'web.keyboard.sendKeyCodeDown',
    displayName: '发送按下键盘按键',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '发送键盘按键 ${keyCode}, 是否按下 ${keyDown}',
    inputs: {
        page: {
            name: 'page',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                label: '网页对象',
                type: 'variable',
                filtersType: 'web.page',
                autoComplete: true
            }
        },
        keyCode: {
            name: 'keyCode',
            value: '',
            type: 'string',
            addConfig: {
                placeholder: '请输入需要发送的键值',
                required: true,
                type: 'select',
                defaultValue: '',
                options: keyCodeMap_1.keyCodeMap,
                label: '键值'
            }
        }
    },
    outputs: {}
};
exports.config = config;
const impl = async function ({ page, keyCode }) {
    await page.keyboard.down(keyCode);
};
exports.impl = impl;
