"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const config = {
    name: 'web.keyboard.sendCharacter',
    sort: 2,
    displayName: '发送字符',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '往页面 ${page} 发送字符 ${char}',
    inputs: {
        page: {
            name: 'page',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                label: '网页对象',
                type: 'variable',
                filtersType: 'web.page',
                autoComplete: true
            }
        },
        char: {
            name: 'char',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                label: '发送的字符',
                required: true,
                placeholder: '请输入要发送的字符',
                type: 'textarea'
            }
        }
    },
    outputs: {}
};
exports.config = config;
const impl = async function ({ page, char }) {
    await page.keyboard.sendCharacter(char);
};
exports.impl = impl;
