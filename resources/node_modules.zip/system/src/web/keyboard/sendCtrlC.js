"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const config = {
    name: 'web.keyboard.sendCtrlC',
    displayName: 'Ctrl+C 复制',
    icon: 'icon-web-copy',
    isControl: false,
    isControlEnd: false,
    comment: '发送键盘组合键Ctrl+C执行复制操作',
    inputs: {
        page: {
            name: 'page',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                label: '网页对象',
                type: 'variable',
                filtersType: 'web.page',
                autoComplete: true,
                required: true // 添加必填校验
            }
        }
    },
    outputs: {}
};
exports.config = config;
const impl = async function ({ page }) {
    // 确保页面焦点
    // await page.bringToFront();
    // 执行复制操作
    await page.keyboard.down('Control');
    await page.keyboard.press('KeyC');
    await page.keyboard.up('Control');
};
exports.impl = impl;
