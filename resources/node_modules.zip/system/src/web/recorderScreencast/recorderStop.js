"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'web.recorderScreencast.recorderStop',
    icon: 'icon-web-stop',
    displayName: '停止录屏',
    comment: '停止当前的录屏并保存文件。',
    inputs: {
        recorderObj: {
            name: 'recorderObj',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                label: '录屏对象',
                type: 'variable',
                required: true,
                filtersType: 'web.recorderScreencast.pageScreenRecord',
                autoComplete: true,
                tip: '传入录屏对象以停止录屏'
            }
        }
    },
    outputs: {}
};
const impl = async function ({ recorderObj: { recorder, filePath } }) {
    // 停止录屏
    await recorder.stop();
    console.log('录屏已停止！文件路径：', filePath);
};
exports.impl = impl;
