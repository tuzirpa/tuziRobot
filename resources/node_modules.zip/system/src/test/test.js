"use strict";
globalThis._tuziAppInfo = { USER_DIR: './' };
globalThis.curApp = { APP_DIR: './' };
const webCreate = require('../../dist/web/webCreate');
webCreate.impl({
    webType: 'chrome',
    url: 'https://www.baidu.com',
    proxyServer: 'd2263432577:e3m0xtdf@218.95.37.135:41701'
});
