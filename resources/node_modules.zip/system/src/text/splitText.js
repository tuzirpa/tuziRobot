"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'text.splitText',
    icon: 'icon-web-create',
    displayName: '分割文本',
    comment: '分割${text}文本，分隔符${splitter}文本,并保存结果至${result}',
    inputs: {
        text: {
            name: 'text',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                label: '原始文本',
                placeholder: '原始文本',
                type: 'textarea',
                required: true
            }
        },
        splitter: {
            name: 'splitter',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                label: '分割符',
                placeholder: '分割符,如: , ; 也可为空，如果为空 则使用空字符串分割',
                type: 'textarea',
                defaultValue: '',
                required: false
            }
        }
    },
    outputs: {
        result: {
            name: '',
            display: '保存结果至',
            type: 'array',
            addConfig: {
                label: '保存结果至',
                type: 'variable',
                defaultValue: 'result'
            }
        }
    }
};
const impl = async function ({ text, splitter }) {
    return { result: text.split(splitter) };
};
exports.impl = impl;
