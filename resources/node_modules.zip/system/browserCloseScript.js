"use strict";
//关闭浏览器监听脚本
(async () => {
    const puppeteer = require('puppeteer-core');
    const fs = require('fs');
    const browserJsonPath = 'browser.json';
    const tempFilePath = 'browserCloseScript.js';
    const wsUrl = 'ws://127.0.0.1:11922/devtools/browser/57c98685-6bb4-4f54-a723-6d1a10328079';
    const browser = await puppeteer.connect({
        browserWSEndpoint: wsUrl,
        defaultViewport: null
    });
    browser.on('disconnected', () => {
        console.log('浏览器已断开连接，关闭浏览器');
        const browserJson = fs.readFileSync(browserJsonPath, 'utf-8');
        let browserJsonObj = JSON.parse(browserJson);
        browserJsonObj = browserJsonObj.filter((item) => item.wsUrl !== wsUrl);
        fs.writeFileSync(browserJsonPath, JSON.stringify(browserJsonObj));
        fs.unlinkSync(tempFilePath);
        process.exit();
    });
})();
