"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const hmc_win32_1 = __importDefault(require("hmc-win32"));
const config = {
    name: 'keyboard.sendCtrlV',
    displayName: 'Ctrl+V 粘贴',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '发送键盘组合键 Ctrl+V 粘贴',
    inputs: {},
    outputs: {}
};
exports.config = config;
const impl = function () {
    return __awaiter(this, void 0, void 0, function* () {
        hmc_win32_1.default.sendBasicKeys(true, false, false, false, 'V');
    });
};
exports.impl = impl;
