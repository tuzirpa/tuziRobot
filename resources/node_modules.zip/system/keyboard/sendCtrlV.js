"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const hmc_win32_1 = __importDefault(require("hmc-win32"));
const config = {
    name: 'keyboard.sendCtrlV',
    displayName: 'Ctrl+V 粘贴',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '发送键盘组合键 Ctrl+V 粘贴',
    inputs: {},
    outputs: {}
};
exports.config = config;
const impl = async function () {
    hmc_win32_1.default.sendBasicKeys(true, false, false, false, 'V');
};
exports.impl = impl;
