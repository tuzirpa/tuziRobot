"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: "excel.getSheets",
    displayName: "获取Excel的所有个工作表",
    icon: "icon-web-create",
    isControl: false,
    isControlEnd: false,
    comment: "从workbook对象读取一个工作表，并保存到${sheet}。",
    inputs: {
        workbook: {
            name: "workbook",
            value: "",
            type: "variable",
            addConfig: {
                required: true,
                label: "excel对象",
                type: "variable",
                filtersType: "excel.workbook",
                autoComplete: true,
            },
        },
    },
    outputs: {
        sheets: {
            name: "",
            display: "工作表对象",
            type: "array",
            addConfig: {
                label: "所有工作表对象",
                type: "variable",
                defaultValue: "sheets",
            },
        },
    },
};
const impl = async function ({ workbook }) {
    const sheets = [];
    workbook.SheetNames.forEach((sheetName) => {
        sheets.push(workbook.Sheets[sheetName]);
    });
    return { sheets };
};
exports.impl = impl;
