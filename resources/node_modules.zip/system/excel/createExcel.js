"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const path_1 = require("path");
const xlsx_1 = __importDefault(require("xlsx"));
exports.config = {
    name: "excel.create",
    displayName: "创建Excel表格",
    icon: "icon-web-create",
    isControl: false,
    isControlEnd: false,
    comment: "新建一个表格文件${fileDir}/${fileName}，保存到变量${workbook}。",
    inputs: {
        fileDir: {
            name: "fileDir",
            value: "",
            type: "string",
            addConfig: {
                required: true,
                placeholder: "请选择保存的文件目录",
                label: "创建的文件目录",
                openDirectory: true,
                type: "filePath",
                defaultValue: "",
                tip: "请选择保存的文件目录",
            },
        },
        fileName: {
            name: "fileName",
            value: "",
            type: "string",
            addConfig: {
                required: true,
                placeholder: "请输入文件名，如：test.xlsx",
                label: "文件名",
                type: "string",
                defaultValue: "",
            },
        },
    },
    outputs: {
        workbook: {
            name: "",
            display: "Excel对象-包含多个工作表",
            type: "excel.workbook",
            addConfig: {
                label: "Excel对象",
                type: "variable",
                defaultValue: "workbook",
            },
        },
    },
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ fileDir, fileName, }) {
        // 创建一个新的工作簿
        const workbook = xlsx_1.default.utils.book_new();
        if (!fileName.endsWith(".xlsx")) {
            fileName += ".xlsx";
        }
        console.log(fileDir, fileName);
        // 新建一个工作表
        const sheetData = [[]];
        const sheet = xlsx_1.default.utils.aoa_to_sheet(sheetData);
        // 将工作表添加到工作簿
        xlsx_1.default.utils.book_append_sheet(workbook, sheet, "Sheet1");
        xlsx_1.default.writeFile(workbook, (0, path_1.join)(fileDir, fileName));
        return { workbook };
    });
};
exports.impl = impl;
