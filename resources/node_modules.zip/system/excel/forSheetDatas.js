"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const xlsx_1 = __importDefault(require("xlsx"));
exports.config = {
    name: "excel.forSheetDatas",
    displayName: "循环工作表数据",
    icon: "icon-web-create",
    isControl: true,
    isLoop: true,
    isControlEnd: false,
    comment: "循环遍历工作表${sheet}，单元格值保存到变量${cellValue}，当前行保存到变量${rowNum}，当前列保存到变量${colNum}。",
    inputs: {
        sheet: {
            name: "sheet",
            value: "",
            type: "variable",
            addConfig: {
                required: true,
                label: "工作表",
                type: "variable",
                filtersType: "excel.sheet",
                autoComplete: true,
            },
        },
    },
    outputs: {
        cellValue: {
            name: "",
            display: "单元格值",
            type: "string",
            addConfig: {
                label: "单元格值",
                type: "variable",
                defaultValue: "cellValue",
            },
        },
        rowNum: {
            name: "",
            display: "数字",
            type: "number",
            addConfig: {
                label: "循环当前行号",
                type: "variable",
                defaultValue: "rowNum",
            },
        },
        colNum: {
            name: "",
            display: "数字",
            type: "number",
            addConfig: {
                label: "循环当前列号",
                type: "variable",
                defaultValue: "colNum",
            },
        },
    },
    toCode(directive, block) {
        return __awaiter(this, void 0, void 0, function* () {
            const { sheet } = directive.inputs;
            const { cellValue, rowNum, colNum } = directive.outputs;
            return `for (let [${cellValue.name}, ${rowNum.name}, ${colNum.name}] of await robotUtil.system.excel.forSheetDatas({ sheet: ${sheet.value} },${block})) {`;
        });
    },
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ sheet }) {
        function* range(sheet) {
            // 解析范围以确定表格的边界
            if (!sheet["!ref"]) {
                // yield [void 0, 0, 0];
                return;
            }
            const range = xlsx_1.default.utils.decode_range(sheet["!ref"]);
            if (range.e.r === 0 && range.e.c === 0) {
                return;
            }
            for (let rowNum = range.s.r; rowNum <= range.e.r; rowNum++) {
                for (let colNum = range.s.c; colNum <= range.e.c; colNum++) {
                    const cellAddress = xlsx_1.default.utils.encode_cell({
                        r: rowNum,
                        c: colNum,
                    });
                    const cell = sheet[cellAddress];
                    let cellValue;
                    // 检查单元格是否有数据
                    if (cell && cell.v !== undefined) {
                        cellValue = cell.v;
                    }
                    yield [cellValue !== null && cellValue !== void 0 ? cellValue : "", rowNum + 1, colNum + 1];
                }
            }
        }
        return range(sheet);
    });
};
exports.impl = impl;
