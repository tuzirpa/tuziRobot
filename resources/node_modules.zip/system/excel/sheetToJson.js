"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const xlsx_1 = __importDefault(require("xlsx"));
exports.config = {
    name: 'excel.sheetToJson',
    displayName: '工作表数据转JSON',
    icon: 'icon-web-create',
    comment: '将工作表${sheet}数据，按表头为key，每行数据为value的JSON格式数据，输出到变量${sheetJsonData}中。',
    inputs: {
        sheet: {
            name: 'sheet',
            value: '',
            type: 'variable',
            addConfig: {
                required: true,
                label: '工作表',
                type: 'variable',
                filtersType: 'excel.sheet',
                autoComplete: true
            }
        }
    },
    outputs: {
        sheetJsonData: {
            name: '',
            display: '表格JSON数据',
            type: 'string',
            addConfig: {
                label: '表格JSON数据',
                type: 'variable',
                defaultValue: 'sheetJsonData'
            }
        }
    }
};
const impl = async function ({ sheet }) {
    const sheetJsonData = xlsx_1.default.utils.sheet_to_json(sheet);
    return { sheetJsonData };
};
exports.impl = impl;
