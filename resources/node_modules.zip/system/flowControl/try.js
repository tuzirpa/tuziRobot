"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'flowControl.try',
    displayName: 'TRY 异常捕获',
    appendDirectiveNames: ['flowControl.catch', 'flowControl.tryEnd'],
    icon: 'icon-warning',
    sort: 20,
    isControl: true,
    isControlEnd: false,
    comment: '尝试执行以下操作，如果发生异常则进入CATCH块处理',
    inputs: {},
    outputs: {},
    async toCode(_directive, _block) {
        return `try {`;
    }
};
const impl = async function () {
    // 实现为空，因为try本身不需要任何逻辑
};
exports.impl = impl;
