"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const commonUtil_1 = require("tuzirobot/commonUtil");
exports.config = {
    name: 'dialog.selectDirectory',
    sort: 2,
    displayName: '弹出选择目录',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '弹出目录选择器，选择目录后返回文件路径保存到变量中${dirPath}',
    inputs: {},
    outputs: {
        dirPath: {
            name: '',
            display: '文件路径',
            type: 'string',
            addConfig: {
                label: '文件路径',
                type: 'variable',
                defaultValue: 'dirPath'
            }
        }
    }
};
const impl = async function () {
    //运行一个electron 并打开文件选择器
    const filePath = await (0, commonUtil_1.invokeApi)('dialog.openDirectory', {});
    return { dirPath: filePath };
};
exports.impl = impl;
