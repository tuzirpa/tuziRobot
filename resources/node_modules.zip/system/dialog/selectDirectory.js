"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const commonUtil_1 = require("tuzirobot/commonUtil");
exports.config = {
    name: 'dialog.selectDirectory',
    sort: 2,
    displayName: '弹出选择目录',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '弹出目录选择器，选择目录后返回文件路径保存到变量中${dirPath}',
    inputs: {},
    outputs: {
        dirPath: {
            name: '',
            display: '文件路径',
            type: 'string',
            addConfig: {
                label: '文件路径',
                type: 'variable',
                defaultValue: 'dirPath'
            }
        }
    }
};
const impl = function () {
    return __awaiter(this, void 0, void 0, function* () {
        //运行一个electron 并打开文件选择器
        const filePath = yield (0, commonUtil_1.invokeApi)('dialog.openDirectory', {});
        return { dirPath: filePath };
    });
};
exports.impl = impl;
