"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const commonUtil_1 = require("tuzirobot/commonUtil");
exports.config = {
    name: "dialog.prompt",
    sort: 2,
    displayName: "弹出输入框",
    icon: "icon-web-create",
    isControl: false,
    isControlEnd: false,
    comment: "弹出一个输入框，用户可以输入文本,保存到变量${content}中",
    inputs: {
        placeholder: {
            name: "placeholder",
            value: "",
            type: "string",
            addConfig: {
                label: "提示语",
                placeholder: "请输入提示语",
                type: "string",
                defaultValue: "请输入内容",
            },
        },
    },
    outputs: {
        content: {
            name: "",
            display: "用户输入的内容",
            type: "string",
            addConfig: {
                label: "用户输入的内容",
                type: "variable",
                defaultValue: "content",
            },
        },
    },
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ placeholder }) {
        //运行一个electron 并打开文件选择器
        const content = yield (0, commonUtil_1.invokeApi)("dialog.prompt", { placeholder });
        return { content };
    });
};
exports.impl = impl;
