"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const commonUtil_1 = require("tuzirobot/commonUtil");
exports.config = {
    name: 'dialog.promptConfirmation',
    sort: 2,
    displayName: '弹出确认框',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '弹出一个确认框，用户需要确认后才能继续执行后续指令。设置的提示语 ${message}',
    inputs: {
        message: {
            name: 'message',
            value: '',
            type: 'string',
            addConfig: {
                label: '提示语',
                placeholder: '请输入提示语',
                type: 'string',
                defaultValue: '请输入内容'
            }
        }
    },
    outputs: {}
};
const impl = async function ({ message }) {
    //运行一个electron 并打开文件选择器
    const content = await (0, commonUtil_1.invokeApi)('dialog.promptConfirmation', { message });
    return { content };
};
exports.impl = impl;
