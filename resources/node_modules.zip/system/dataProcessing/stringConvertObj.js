"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'dataProcessing.stringConvertObj',
    displayName: 'JSON字符串转对象',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '将JSON字符串${jsonContent}转换为对象,并输出到变量${jsonObj}',
    inputs: {
        jsonContent: {
            name: 'jsonContent',
            value: '',
            type: 'string',
            addConfig: {
                label: 'Json文本',
                type: 'textarea',
                placeholder: '请输入json文本 例如：{"name": "tuzi", "age": 18}',
                defaultValue: '',
                tip: ''
            }
        }
    },
    outputs: {
        jsonObj: {
            name: '',
            type: 'any',
            display: 'JSON对象',
            addConfig: {
                label: 'JSON对象',
                type: 'variable',
                defaultValue: 'JSON对象',
                tip: ''
            }
        }
    }
};
const impl = async function ({ jsonContent }) {
    const jsonObj = JSON.parse(jsonContent);
    return { jsonObj };
};
exports.impl = impl;
