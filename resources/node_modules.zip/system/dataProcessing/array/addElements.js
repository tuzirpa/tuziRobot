"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: "dataProcessing.array.addElements",
    displayName: "添加数组元素(批量传入数组)",
    comment: "数组对象${array}中，在数组末尾添加元素${value}",
    inputs: {
        array: {
            name: "array",
            value: "",
            display: "数组对象",
            type: "variable",
            addConfig: {
                label: "数组对象",
                type: "variable",
                placeholder: "选择数组对象",
                filtersType: "array",
                required: true,
            },
        },
        value: {
            name: "value",
            value: "",
            display: "数组元素值",
            type: "variable",
            addConfig: {
                label: "要添加的数据数组",
                placeholder: "请输入要添加的数组",
                type: "variable",
                filtersType: "array",
                autoComplete: true,
                defaultValue: "",
                required: true,
            },
        },
    },
    outputs: {},
};
const impl = async function ({ array, value, }) {
    array.push(...value);
};
exports.impl = impl;
