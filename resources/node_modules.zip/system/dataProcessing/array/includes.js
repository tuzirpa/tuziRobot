"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: "dataProcessing.array.includes",
    displayName: "数组是否包含指定值",
    comment: "数组对象${array}中，是否包含${value}",
    inputs: {
        array: {
            name: "array",
            value: "",
            display: "数组对象",
            type: "variable",
            addConfig: {
                label: "数组对象",
                type: "variable",
                defaultValue: "",
            },
        },
        value: {
            name: "value",
            value: "",
            display: "数组元素值",
            type: "string",
            addConfig: {
                label: "数组元素值",
                placeholder: "请输入要添加的元素值",
                type: "variable",
                defaultValue: "",
                required: true,
            },
        },
    },
    outputs: {
        isInclude: {
            name: "isInclude",
            display: "数组元素是否包含指定值",
            type: "string",
            addConfig: {
                label: "是否包含指定值",
                type: "variable",
                defaultValue: "",
            },
        },
    },
};
const impl = async function ({ array, value, }) {
    const isInclude = array.includes(value);
    return { isInclude };
};
exports.impl = impl;
