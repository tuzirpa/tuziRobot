"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'web.getIframe',
    icon: 'icon-web-create',
    displayName: '获取iframe',
    comment: '在页面${browserPage}中获取子页面url 包含 ${iframeSelector}保存到${webIframe}',
    inputs: {
        browserPage: {
            name: 'browserPage',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                label: '标签页对象',
                placeholder: '选择标签页对象',
                type: 'variable',
                filtersType: 'web.page',
                autoComplete: true
            }
        },
        iframeSelector: {
            name: 'iframeSrc',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                label: 'iframe的url',
                placeholder: '请输入iframe的url（src属性）',
                type: 'string'
            }
        }
    },
    outputs: {
        webIframe: {
            name: '',
            display: 'iframe页面',
            type: 'web.iframe',
            addConfig: {
                label: '对象',
                type: 'variable',
                defaultValue: 'webFrame'
            }
        }
    }
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ browserPage, iframeSelector }) {
        const webIframe = browserPage.frames().find((frame) => frame.url().includes(iframeSelector));
        return { webIframe };
    });
};
exports.impl = impl;
