"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'web.elementScrollIntoView',
    sort: 2,
    displayName: '将元素滚动到视图中',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '将元素${element}滚动到视图中，使其可见。',
    inputs: {
        element: {
            name: 'element',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                required: true,
                label: '元素对象',
                type: 'variable',
                filtersType: 'web.Element',
                autoComplete: true
            }
        }
    },
    outputs: {}
};
const impl = async function ({ element }) {
    await element.scrollIntoView();
};
exports.impl = impl;
