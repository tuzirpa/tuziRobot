"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
// import { Page } from 'puppeteer-core';
const puppeteer_core_1 = __importDefault(require("puppeteer-core"));
const commonUtil_1 = require("tuzirobot/commonUtil");
const child_process_1 = __importStar(require("child_process"));
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const portUtils_1 = require("./utils/portUtils");
// import StealthPlugin from 'puppeteer-extra-plugin-stealth';
// puppeteer.use(StealthPlugin());
exports.config = {
    name: 'web.create',
    displayName: '创建浏览器',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '启动${webType}并打开${url},保存至：${browser}',
    inputs: {
        webType: {
            name: 'webType',
            value: '',
            display: '内置浏览器',
            type: 'string',
            addConfig: {
                required: true,
                label: '浏览器类型',
                type: 'select',
                options: [
                    {
                        label: '内置浏览器',
                        value: 'tuziChrome'
                    },
                    {
                        label: '谷歌浏览器',
                        value: 'chrome'
                    },
                    {
                        label: 'Edge',
                        value: 'edge'
                    },
                    {
                        label: '自定义浏览器路径',
                        value: 'custom'
                    }
                ],
                defaultValue: 'tuziChrome',
                tip: '选择浏览器类型'
            }
        },
        executablePath: {
            name: 'executablePath',
            value: '',
            type: 'string',
            addConfig: {
                label: '浏览器路径',
                placeholder: '如填写请输入浏览器路径，如：C:/Program Files (x86)/Google/Chrome/Application/chrome.exe',
                type: 'filePath',
                defaultValue: '',
                tip: '浏览器路径',
                filters: 'this.inputs.webType.value === "custom"'
            }
        },
        url: {
            name: 'url',
            value: '',
            type: 'string',
            addConfig: {
                label: '地址',
                type: 'textarea',
                placeholder: '选填，如填写请输入地址 如：http://www.baidu.com 或 https://www.taobao.com',
                defaultValue: '',
                tip: '打开的地址'
            }
        },
        loadTimeout: {
            name: 'timeout',
            value: '30',
            type: 'number',
            addConfig: {
                label: '超时',
                type: 'string',
                placeholder: '不填或填0表示一直等待到加载完成，打开url超时时间，单位：秒',
                isAdvanced: true,
                required: true,
                defaultValue: '30',
                tip: '超时时间，单位：秒'
            }
        },
        userDataDir: {
            name: 'userDataDir',
            value: '',
            type: 'string',
            addConfig: {
                label: '用户目录',
                placeholder: '记录 cookie、缓存、用户登录数据等（比如 网站的登录状态）。',
                type: 'filePath',
                defaultValue: '',
                openDirectory: true,
                tip: '默认在使用当前应用的目录下创建userData目录，可自定义'
            }
        }
    },
    outputs: {
        browser: {
            name: '',
            display: '浏览器对象',
            type: 'web.browser',
            addConfig: {
                label: '浏览器对象',
                type: 'variable',
                defaultValue: 'web_browser'
            }
        },
        page: {
            name: '',
            display: '标签页对象',
            type: 'web.page',
            addConfig: {
                label: '标签页对象',
                type: 'variable',
                defaultValue: 'page'
            }
        }
    }
};
function regQueryExeCutablePath(regPath) {
    return new Promise((resolve, reject) => {
        child_process_1.default.exec(`REG QUERY "${regPath}"`, function (error, stdout, _stderr) {
            if (error != null) {
                reject(error);
                return;
            }
            let exePath = '';
            const lines = stdout.split('\n');
            for (let index = 0; index < lines.length; index++) {
                const line = lines[index];
                line.indexOf('REG_SZ') !== -1 &&
                    (exePath = line.substring(line.indexOf('REG_SZ') + 6));
                if (exePath) {
                    break;
                }
            }
            const ep = exePath.trim().replace(/\\/g, '/');
            resolve(ep);
        });
    });
}
function getExeCutablePath(type) {
    return __awaiter(this, void 0, void 0, function* () {
        //读取注册表获取浏览器路径
        let path = '';
        function regeditGet(regPoint, type) {
            return __awaiter(this, void 0, void 0, function* () {
                let path1 = '';
                switch (type) {
                    case 'chrome':
                        //读取windows注册表 HKEY_LOCAL_MACHINE\SOFTWARE\Clients\StartMenuInternet\Google Chrome\DefaultIcon
                        path1 = yield regQueryExeCutablePath(`${regPoint}\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\chrome.exe`);
                        break;
                    case 'edge':
                        //HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe
                        path1 = yield regQueryExeCutablePath(`${regPoint}\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\msedge.exe`);
                        break;
                    default:
                        break;
                }
                return path1;
            });
        }
        try {
            path = yield regeditGet('HKEY_CURRENT_USER', type);
        }
        catch (error) {
            path = '';
        }
        if (!path) {
            path = yield regeditGet('HKEY_LOCAL_MACHINE', type);
        }
        return path;
    });
}
const impl = function (_a, _block_1) {
    return __awaiter(this, arguments, void 0, function* ({ webType, url, loadTimeout, executablePath, userDataDir }, _block) {
        var _b;
        let executablePathA = '';
        console.log(webType, 'webType');
        const tuziAppInfo = (0, commonUtil_1.getTuziAppInfo)();
        const curApp = (0, commonUtil_1.getCurApp)();
        if (webType === 'custom') {
            executablePathA = executablePath;
        }
        else {
            if (webType !== 'tuziChrome') {
                executablePathA = yield getExeCutablePath(webType);
                if (!executablePathA) {
                    const webBrowser = (_b = exports.config.inputs.webType.addConfig.options) === null || _b === void 0 ? void 0 : _b.find((item) => item.value === webType);
                    throw new Error(`本地未安装 ${webBrowser === null || webBrowser === void 0 ? void 0 : webBrowser.label}，请设置先安装`);
                }
            }
            else {
                executablePathA = path_1.default.join(tuziAppInfo.USER_DIR, 'tuziChrome', 'chrome-win64', 'chrome.exe');
                if (!fs_1.default.existsSync(executablePathA)) {
                    throw new Error(`内置浏览器还未安装完成，请等待安装完成后使用`);
                }
            }
        }
        //设备信息整合
        const ops = {
            headless: false,
            defaultViewport: null,
            ignoreDefaultArgs: ['--enable-automation'],
            args: ['--no-sandbox', '--disable-setuid-sandbox']
        };
        executablePathA && (ops.executablePath = executablePathA);
        console.debug('浏览器路径', ops.executablePath);
        ops.userDataDir = userDataDir || path_1.default.join(curApp.APP_DIR, 'userData');
        console.debug('用户目录', userDataDir);
        const port = yield (0, portUtils_1.getAvailablePort)(11922);
        console.debug('端口', port);
        const args = ['--start-maximized'];
        const startCmd = `"${ops.executablePath}" --remote-debugging-port=${port} --disk-cache-dir="${ops.userDataDir}" --user-data-dir="${ops.userDataDir}" ${args.join(' ')}`;
        console.debug('启动命令', startCmd);
        let browser;
        const browserJsonPath = path_1.default.join(tuziAppInfo.USER_DIR, 'browser.json');
        if (!fs_1.default.existsSync(browserJsonPath)) {
            fs_1.default.writeFileSync(browserJsonPath, JSON.stringify([]));
        }
        const browserJson = fs_1.default.readFileSync(browserJsonPath, 'utf-8');
        const browserJsonObj = JSON.parse(browserJson);
        let wsUrl;
        const startRes = yield new Promise((resolve, reject) => {
            var _a;
            const child = (0, child_process_1.exec)(startCmd);
            // 子进程代码
            const closeBack = (data) => {
                if (data.action === 'close') {
                    (0, commonUtil_1.sendLog)('info', `接收停止消息：${JSON.stringify(data)}`, _block);
                    child.kill();
                }
            };
            process.on('message', closeBack);
            process.on('exit', () => {
                console.log('应用进程退出,关闭浏览器');
                browser && browser.close();
                const browserJson = fs_1.default.readFileSync(browserJsonPath, 'utf-8');
                let browserJsonObj = JSON.parse(browserJson);
                browserJsonObj = browserJsonObj.filter((item) => item.wsUrl !== wsUrl);
                fs_1.default.writeFileSync(browserJsonPath, JSON.stringify(browserJsonObj));
                process.off('message', closeBack);
            });
            child.on('error', (err) => {
                reject(err);
            });
            child.on('exit', (code, signal) => {
                (0, commonUtil_1.sendLog)('info', `浏览器进程已退出，退出码：${code}，信号：${signal}`, _block);
                browser && browser.close();
                const browserJson = fs_1.default.readFileSync(browserJsonPath, 'utf-8');
                let browserJsonObj = JSON.parse(browserJson);
                browserJsonObj = browserJsonObj.filter((item) => item.wsUrl !== wsUrl);
                fs_1.default.writeFileSync(browserJsonPath, JSON.stringify(browserJsonObj));
                process.off('message', closeBack);
            });
            (_a = child.stderr) === null || _a === void 0 ? void 0 : _a.on('data', (data) => {
                const err = data.toString();
                const matchData = data.match(/ws:\/\/127.0.0.1:\d+\/devtools\/browser\/[0-9A-Za-z-]+/);
                if (err.includes('listening on ws://127.0.0.1:') && matchData) {
                    wsUrl = matchData[0];
                    resolve(wsUrl);
                }
            });
        });
        console.log('启动成功 wsUrl:', startRes);
        browserJsonObj.push({
            wsUrl: startRes,
            appName: curApp.APP_NAME,
            appId: curApp.APP_ID,
            time: new Date().toLocaleString()
        });
        fs_1.default.writeFileSync(browserJsonPath, JSON.stringify(browserJsonObj));
        browser = yield puppeteer_core_1.default.connect({
            browserWSEndpoint: startRes,
            defaultViewport: ops.defaultViewport
        });
        // browser.on('targetcreated', async (target) => {
        //     if (target.type() === 'page') {
        //         const page = await target.page();
        //         if (page) {
        //             await setBrowserPage(page);
        //         }
        //     }
        // });
        console.log('浏览器连接成功');
        const pages = yield browser.pages();
        console.log('标签页数量', pages.length);
        const page = pages[pages.length - 1];
        // await setBrowserPage(page);
        if (url) {
            console.log('打开地址', url);
            url.startsWith('http') || (url = 'http://' + url);
            yield page.goto(url, { timeout: loadTimeout * 1000 });
        }
        return { browser, page };
    });
};
exports.impl = impl;
