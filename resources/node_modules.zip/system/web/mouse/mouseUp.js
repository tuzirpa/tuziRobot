"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'web.mouseUp',
    icon: 'icon-web-create',
    displayName: '释放鼠标',
    comment: '在页面${page}中, 按下鼠标${button}键后释放鼠标',
    inputs: {
        page: {
            name: 'page',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                label: '标签页对象',
                type: 'variable',
                filtersType: 'web.page',
                autoComplete: true
            }
        },
        button: {
            name: 'button',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                label: '鼠标按下键',
                type: 'string',
                filtersType: 'web.mouseButton',
                required: true,
                autoComplete: true
            }
        }
    },
    outputs: {}
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ page, button }) {
        yield page.mouse.up({ button });
        console.log('鼠标释放成功', button);
    });
};
exports.impl = impl;
