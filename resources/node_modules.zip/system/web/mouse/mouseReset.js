"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'web.mouse.mouseReset',
    icon: 'icon-web-create',
    displayName: '重置鼠标为默状态',
    comment: '在页面${page}中，重置鼠标为默认状态，位置（0，0）',
    inputs: {
        page: {
            name: 'page',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                label: '标签页对象',
                type: 'variable',
                filtersType: 'web.page',
                autoComplete: true
            }
        }
    },
    outputs: {}
};
const impl = async function ({ page }) {
    await page.mouse.reset();
};
exports.impl = impl;
