"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'web.elementOperate.waitForElement',
    sort: 5,
    displayName: '等待元素出现并消失',
    icon: 'icon-wait',
    isControl: false,
    isControlEnd: false,
    comment: '在页面${browserPage}中，等待元素${selector}出现后消失，超时时间${timeout}秒',
    inputs: {
        browserPage: {
            name: 'browserPage',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                label: '网页对象',
                type: 'variable',
                filtersType: 'web.page',
                autoComplete: true,
                required: true
            }
        },
        selector: {
            name: 'selector',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                required: true,
                elementLibrarySupport: true,
                placeholder: '请输入CSS或XPath选择器 (例如: #id, .class, //div/span)',
                label: 'CSS或XPath选择器',
                type: 'textarea'
            }
        },
        timeout: {
            name: 'timeout',
            value: '',
            type: 'number',
            addConfig: {
                isAdvanced: true,
                label: '超时时间',
                type: 'string',
                defaultValue: '30',
                tip: '等待元素出现和消失的超时时间（秒）'
            }
        }
    },
    outputs: {}
};
const impl = async function ({ browserPage, selector, timeout = 30 }) {
    try {
        if (!browserPage) {
            throw new Error('浏览器页面对象不能为空');
        }
        if (selector.startsWith('//')) {
            selector = `::-p-xpath(${selector})`;
        }
        // 等待元素出现
        const element = await browserPage.waitForSelector(selector, {
            timeout: timeout * 1000
        });
        console.debug('元素出现');
        // 等待元素消失
        await browserPage.waitForFunction((el) => {
            if (!el) {
                return true;
            }
            const rect = el.getBoundingClientRect();
            const style = window.getComputedStyle(el);
            const isHidden = style.visibility === 'hidden' || style.display === 'none';
            return (isHidden || // 元素被隐藏
                rect.top + rect.height < 0 || // 元素在视口上方
                rect.bottom > window.innerHeight // 元素在视口下方
            );
        }, {}, element, { timeout: timeout * 1000 });
        console.debug('元素消失');
    }
    catch (error) {
        console.error('等待元素出现或消失失败:', error);
        throw error;
    }
};
exports.impl = impl;
