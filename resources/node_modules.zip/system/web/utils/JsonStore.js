"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.JsonStorage = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const commonUtil_1 = require("tuzirobot/commonUtil");
class JsonStorage {
    constructor(filePath) {
        filePath = filePath || './data.json';
        const app = (0, commonUtil_1.getCurApp)();
        this.filePath = path_1.default.join(app.APP_DIR, 'runtime', filePath); // 解析为绝对路径
        if (!fs_1.default.existsSync(this.filePath)) {
            fs_1.default.mkdirSync(path_1.default.dirname(this.filePath), { recursive: true });
            fs_1.default.writeFileSync(this.filePath, '{}', 'utf8');
        }
        this.load();
    }
    // 读取 JSON 文件内容
    read() {
        try {
            const data = fs_1.default.readFileSync(this.filePath, 'utf8');
            const parsedData = JSON.parse(data);
            return parsedData;
        }
        catch (err) {
            if (err instanceof SyntaxError) {
                // 处理 JSON 解析错误
                throw new Error('JSON 解析错误');
            }
            if (err.code === 'ENOENT') {
                // 文件不存在时返回空对象
                return {};
            }
            throw err;
        }
    }
    // 写入 JSON 数据到文件
    write(data) {
        const jsonData = JSON.stringify(data, null, 2);
        if (fs_1.default.existsSync(this.filePath)) {
            fs_1.default.writeFileSync(this.filePath, jsonData, 'utf8');
        }
        else {
            fs_1.default.mkdirSync(path_1.default.dirname(this.filePath), { recursive: true });
            fs_1.default.writeFileSync(this.filePath, jsonData, 'utf8');
        }
    }
    // 更新 JSON 数据
    set(key, value) {
        this.currentData[key] = value;
        this.write(this.currentData);
        return this.currentData;
    }
    get(key) {
        return this.currentData[key];
    }
    delete(key) {
        delete this.currentData[key];
        this.write(this.currentData);
    }
    clear() {
        this.currentData = {};
        this.write(this.currentData);
    }
    save() {
        this.write(this.currentData);
    }
    load() {
        this.currentData = this.read();
    }
}
exports.JsonStorage = JsonStorage;
