"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
// import { setBrowserPage } from './utils';
exports.config = {
    name: 'web.createPage',
    displayName: '创建标签页',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '在浏览器${browserPage}中创建标签页,保存至：${page}',
    inputs: {
        browserPage: {
            name: 'browserPage',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                label: '浏览器对象',
                type: 'variable',
                filtersType: 'web.browser',
                autoComplete: true
            }
        }
    },
    outputs: {
        page: {
            name: '',
            display: '标签页对象',
            type: 'web.page',
            addConfig: {
                label: '标签页对象',
                type: 'variable',
                defaultValue: 'page'
            }
        }
    }
};
const impl = async function ({ browserPage }) {
    const page = await browserPage.newPage();
    // await setBrowserPage(page);
    return { page };
};
exports.impl = impl;
