"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'web.pages.getPageUrl',
    sort: 5,
    displayName: '获取标签页URL',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '获取标签页${page}的URL地址',
    inputs: {
        page: {
            name: 'page',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                required: true,
                label: '标签页对象',
                type: 'variable',
                filtersType: 'web.page',
                autoComplete: true,
                tip: '要获取URL的标签页对象'
            }
        }
    },
    outputs: {
        url: {
            name: 'url',
            type: 'string',
            display: '页面URL',
            addConfig: {
                label: '页面URL',
                type: 'variable'
            }
        }
    }
};
const impl = async function ({ page }) {
    try {
        if (!page) {
            throw new Error('标签页对象不能为空');
        }
        const url = await page.url();
        return { url };
    }
    catch (error) {
        console.error('获取标签页URL失败:', error);
        throw error;
    }
};
exports.impl = impl;
