"use strict";
/**
 * 浏览器弹窗处理指令使用示例
 *
 * 这个指令可以自动处理浏览器中的各种弹窗，包括：
 * - alert: 警告弹窗
 * - confirm: 确认弹窗
 * - prompt: 输入弹窗
 * - beforeunload: 页面离开确认弹窗
 *
 * 使用方法：
 * 1. 在页面操作之前先设置弹窗监听器
 * 2. 选择处理动作：接受或拒绝
 * 3. 对于prompt类型弹窗，可以指定输入文本
 *
 * 示例场景：
 * 1. 自动接受所有弹窗
 * 2. 自动拒绝所有弹窗
 * 3. 处理prompt弹窗并输入指定文本
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.notes = exports.example4 = exports.example3 = exports.example2 = exports.example1 = void 0;
// 示例1: 自动接受所有弹窗
exports.example1 = `
// 设置自动接受所有弹窗
const result1 = await web.autoHandleDialog({
    browserPage: page,
    action: 'accept'
});

// 然后执行可能触发弹窗的操作
await page.evaluate(() => {
    alert('这是一个警告弹窗');
    confirm('这是一个确认弹窗');
    prompt('请输入您的姓名:', '默认值');
});
`;
// 示例2: 自动拒绝所有弹窗
exports.example2 = `
// 设置自动拒绝所有弹窗
const result2 = await web.autoHandleDialog({
    browserPage: page,
    action: 'dismiss'
});

// 执行可能触发弹窗的操作
await page.evaluate(() => {
    confirm('您确定要删除这个文件吗？');
});
`;
// 示例3: 处理prompt弹窗并输入文本
exports.example3 = `
// 设置处理prompt弹窗并输入指定文本
const result3 = await web.autoHandleDialog({
    browserPage: page,
    action: 'accept',
    promptText: '张三'
});

// 执行可能触发prompt弹窗的操作
await page.evaluate(() => {
    const name = prompt('请输入您的姓名:', '');
    console.log('输入的姓名:', name);
});
`;
// 示例4: 完整的自动化流程
exports.example4 = `
// 完整的自动化流程示例
async function automateWithDialogHandling() {
    // 1. 创建浏览器页面
    const browser = await web.webCreate();
    const page = await web.createPage({ browser });
    
    // 2. 设置弹窗处理
    const dialogResult = await web.autoHandleDialog({
        browserPage: page,
        action: 'accept',
        promptText: '自动化测试'
    });
    
    // 3. 导航到页面
    await web.pageGotoUrl({
        browserPage: page,
        url: 'https://example.com'
    });
    
    // 4. 执行可能触发弹窗的操作
    await web.pageExecuteScript({
        browserPage: page,
        script: \`
            // 模拟用户操作触发弹窗
            if (confirm('是否继续操作？')) {
                const name = prompt('请输入姓名:', '');
                alert('欢迎 ' + name + '!');
            }
        \`
    });
    
    // 5. 检查弹窗处理结果
    if (dialogResult.isHandled) {
        console.log('弹窗已处理:', dialogResult.dialogMessage);
        console.log('弹窗类型:', dialogResult.dialogType);
    }
    
    // 6. 关闭页面
    await web.closePage({ browserPage: page });
    await web.closeBrowser({ browser });
}
`;
// 注意事项
exports.notes = `
注意事项：
1. 弹窗监听器需要在弹窗出现之前设置
2. 监听器会持续监听，直到页面关闭
3. 对于prompt弹窗，如果不提供promptText，将使用空字符串
4. 处理结果会返回弹窗的消息和类型信息
5. 建议在页面操作开始前就设置好弹窗处理策略
`;
