"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const keyCodeMap_1 = require("../utils/keyCodeMap");
const config = {
    name: 'web.keyboard.sendKeyCode',
    displayName: '发送一次完整按键（按下+松开）',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '发送键盘按键 ${keyCode} 按下 ${time} 毫秒后松开 ',
    inputs: {
        page: {
            name: 'page',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                label: '网页对象',
                type: 'variable',
                filtersType: 'web.page',
                autoComplete: true
            }
        },
        keyCode: {
            name: 'keyCode',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                placeholder: '请输入需要发送的键值',
                required: true,
                label: '键值',
                type: 'select',
                defaultValue: '',
                options: keyCodeMap_1.keyCodeMap
            }
        },
        time: {
            name: 'time',
            value: '',
            type: 'number',
            addConfig: {
                placeholder: '请输入按键持续时间（单位：毫秒）',
                required: true,
                label: '按下持续时间',
                type: 'string',
                defaultValue: '0'
            }
        }
    },
    outputs: {}
};
exports.config = config;
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ page, keyCode, time }) {
        yield page.keyboard.down(keyCode);
        yield new Promise((resolve) => setTimeout(resolve, time));
        yield page.keyboard.up(keyCode);
    });
};
exports.impl = impl;
