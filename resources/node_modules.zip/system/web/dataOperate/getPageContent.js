"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'web.getPageContent',
    icon: 'icon-web-create',
    displayName: '获取标签页内容',
    comment: '在页面${page}中获取当前标签页的${webContent}内容，保存到变量${content}中',
    inputs: {
        page: {
            name: 'page',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                label: '标签页对象',
                type: 'variable',
                filtersType: 'web.page',
                autoComplete: true
            }
        },
        webContent: {
            name: 'webContent',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                label: '获取内容',
                type: 'select',
                required: true,
                options: [
                    { label: '获取HTML', value: 'html' },
                    { label: '获取文本', value: 'text' }
                ],
                defaultValue: 'html'
            }
        }
    },
    outputs: {
        content: {
            name: 'content',
            display: '页面内容',
            type: 'string',
            addConfig: {
                label: '页面内容',
                type: 'variable',
                defaultValue: ''
            }
        }
    }
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ page, webContent }) {
        const content = yield page.content();
        if (webContent === 'html') {
            return { content };
        }
        else if (webContent === 'text') {
            return { content: content.replace(/<[^>]+>/g, '') };
        }
        return { content: '' };
    });
};
exports.impl = impl;
