"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const utils_1 = require("./utils");
exports.config = {
    name: 'web.cssNoNeedGetElement',
    sort: 2,
    displayName: 'CSS或XPath无需等待获取元素',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '在页面对象${browserPage}中，使用CSS或XPath选择器${selector}查找元素，无需等待获取元素。返回元素对象${webElement}。',
    inputs: {
        browserPage: {
            name: 'browserPage',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                label: '网页对象',
                type: 'variable',
                filtersType: 'web.page',
                autoComplete: true
            }
        },
        selector: {
            name: 'selector',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                required: true,
                label: 'CSS或XPath选择器',
                type: 'textarea'
            }
        }
    },
    outputs: {
        webElement: {
            name: '',
            display: '元素对象',
            type: 'web.Element',
            addConfig: {
                label: '元素对象',
                type: 'variable',
                defaultValue: 'webElement'
            }
        }
    }
};
const impl = async function ({ browserPage, selector }) {
    selector = (0, utils_1.toSelector)(selector);
    let webElement = await browserPage.$(selector);
    return { webElement: webElement ? webElement : '' };
};
exports.impl = impl;
