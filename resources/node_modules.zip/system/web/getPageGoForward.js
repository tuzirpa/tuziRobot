"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'web.getPageGoForward',
    icon: 'icon-web-create',
    displayName: '前进一页',
    comment: '在页面${page}中前进一页',
    inputs: {
        page: {
            name: 'page',
            value: '',
            display: '',
            type: 'variable',
            addConfig: {
                label: '页面对象',
                type: 'variable',
                filtersType: 'web.page',
                autoComplete: true
            }
        }
    },
    outputs: {}
};
const impl = async function ({ page }) {
    await page.goForward();
    console.log('前进一页');
};
exports.impl = impl;
