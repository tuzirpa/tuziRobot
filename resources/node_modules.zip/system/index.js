"use strict";
const exportsModule = {};
const directives = require('./directive');
function loadModule(directive) {
    if (directive.children && directive.children.length > 0) {
        directive.children.forEach((child) => {
            loadModule(child);
        });
    }
    else {
        const tModule = require(directive.localFile);
        const config = tModule.config;
        if (config && config.name) {
            //xxx.yyy
            const keys = config.key || config.name;
            const namespace = keys.split('.');
            let t1, t2;
            const configName = namespace.pop();
            namespace.forEach((name, index) => {
                if (index === 0) {
                    t1 = exportsModule[name] || {};
                    exportsModule[name] = t1;
                }
                else {
                    t1[name] = t1[name] || {};
                    t2 = t1[name];
                    t1 = t2;
                }
            });
            t1[configName] = tModule.impl;
        }
    }
}
directives.forEach((directive) => {
    loadModule(directive);
});
module.exports = exportsModule;
