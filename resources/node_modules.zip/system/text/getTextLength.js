"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'text.getTextLenth',
    icon: 'icon-web-create',
    displayName: '获取文本长度',
    comment: '获取${text}文本的长度，并将结果保存到变量${textLength}中',
    inputs: {
        text: {
            name: 'text',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                label: '文本内容',
                placeholder: '文本内容',
                type: 'textarea',
                required: true
            }
        }
    },
    outputs: {
        textLength: {
            name: '',
            display: '文本长度',
            type: 'string',
            addConfig: {
                label: '文本长度',
                type: 'variable',
                defaultValue: 'textLength'
            }
        }
    }
};
const impl = async function ({ text }) {
    const textLength = text ? text.length : 0;
    return { textLength };
};
exports.impl = impl;
