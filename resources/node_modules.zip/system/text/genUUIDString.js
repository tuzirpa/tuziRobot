"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const node_crypto_1 = require("node:crypto");
exports.config = {
    name: 'text.genUUIDString',
    icon: 'icon-web-create',
    displayName: '生成唯一文本',
    description: '生成一个随机的UUID字符串(32位文本 列如: 476b252642c14be29194c320d086d655)，并保存到变量中',
    comment: '生成唯一文本,保存到变量${text}',
    inputs: {},
    outputs: {
        text: {
            name: '',
            display: '字符串',
            type: 'string',
            addConfig: {
                label: '生成的文本',
                type: 'variable',
                defaultValue: '唯一文本'
            }
        }
    }
};
const impl = function () {
    return __awaiter(this, void 0, void 0, function* () {
        const text = (0, node_crypto_1.randomUUID)().replace(/-/g, '');
        return { text };
    });
};
exports.impl = impl;
