"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const axios_1 = __importDefault(require("axios"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const config = {
    name: 'network.downloadFile',
    sort: 2,
    displayName: '下载文件',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '文件${url} 下载到 ${downloadPath}/${fileName}',
    inputs: {
        url: {
            name: 'url',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                label: '下载链接',
                required: true,
                type: 'string',
                placeholder: '请输入URL'
            }
        },
        protocolHeader: {
            name: 'protocolHeader',
            value: '',
            display: '',
            type: 'textarea',
            addConfig: {
                label: '协议头',
                type: 'textarea',
                placeholder: `设置请求协议头，例如：
        Accept: application/json, text/plain, */*
        Accept-Encoding: gzip, deflate, br, zstd
        Accept-Language: zh-CN,zh;q=0.9
        Cache-Control: no-cache
        `,
                defaultValue: ''
            }
        },
        downloadPath: {
            name: 'downloadPath',
            value: '',
            type: 'string',
            addConfig: {
                label: '下载目录',
                type: 'filePath',
                defaultValue: '',
                openDirectory: true,
                tip: '下载保存路径',
                required: true
            }
        },
        fileName: {
            name: 'fileName',
            value: '',
            type: 'string',
            addConfig: {
                label: '保存的文件名',
                placeholder: '请输入文件名, 留空则使用URL文件名',
                type: 'filePath',
                defaultValue: '',
                tip: '保存的文件名',
                required: false
            }
        }
    },
    outputs: {
        filePath: {
            name: '',
            display: '文件路径',
            type: 'string',
            addConfig: {
                label: '文件路径',
                type: 'variable',
                defaultValue: 'filePath'
            }
        }
    }
};
exports.config = config;
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ url, downloadPath, fileName, protocolHeader }) {
        const downloadFile = () => __awaiter(this, void 0, void 0, function* () {
            let headers;
            if (protocolHeader) {
                headers = protocolHeader.split('\n').reduce((acc, cur) => {
                    const [key, value] = cur.split(': ');
                    if (key && value) {
                        acc[key.trim()] = value.trim();
                    }
                    return acc;
                }, {});
            }
            const response = yield (0, axios_1.default)({
                headers: headers,
                method: 'GET',
                url: url,
                responseType: 'stream', // 指定响应数据的流类型
                onDownloadProgress: (progressEvent) => {
                    if (progressEvent.total) {
                        const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
                        console.debug(`下载进度... ${percentCompleted}%`);
                    }
                    else {
                        console.debug(`开始下载...`);
                    }
                }
            });
            if (!fs_1.default.existsSync(downloadPath)) {
                fs_1.default.mkdirSync(downloadPath, { recursive: true });
            }
            let tempName = path_1.default.basename(url);
            if (tempName.includes('?')) {
                tempName = tempName.split('?')[0];
            }
            const tempFileName = fileName || tempName;
            downloadPath = path_1.default.join(downloadPath, tempFileName);
            return new Promise((resolve, reject) => {
                // 使用管道流将响应数据直接写入文件
                const writer = fs_1.default.createWriteStream(downloadPath);
                writer.on('error', (err) => {
                    reject(err);
                });
                response.data.pipe(writer);
                response.data.on('end', () => {
                    resolve(downloadPath);
                    console.log('文件下载成功!', downloadPath);
                });
                response.data.on('error', (err) => {
                    reject(err);
                    console.error('文件下载失败:', err);
                });
            });
        });
        const filePath = yield downloadFile();
        return { filePath };
    });
};
exports.impl = impl;
