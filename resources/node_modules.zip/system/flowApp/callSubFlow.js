"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const path_1 = require("path");
const commonUtil_1 = require("tuzirobot/commonUtil");
const fs_1 = __importDefault(require("fs"));
exports.config = {
    name: 'flowApp.callSubFlow',
    displayName: '调用子流程',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '调用子流程${flowName}, 参数为${params}, 并返回子流程的返回值保存到${returnVal}变量中',
    inputs: {
        flowName: {
            name: 'flowName',
            value: '',
            type: 'string',
            addConfig: {
                label: '子流程名称',
                type: 'string',
                required: true,
                defaultValue: '',
                tip: '子流程名称'
            }
        },
        params: {
            name: 'params',
            value: '',
            type: 'array',
            addConfig: {
                label: '参数',
                type: 'variable',
                multiple: true,
                required: false,
                defaultValue: '',
                tip: '子流程参数'
            }
        }
    },
    outputs: {
        returnVal: {
            name: '',
            display: '数组-子流程返回值',
            type: 'array',
            addConfig: {
                label: '返回值',
                type: 'variable',
                required: true,
                defaultValue: 'subFlowReturnVal',
                tip: '子流程返回的结果'
            }
        }
    }
};
const impl = function (_a) {
    return __awaiter(this, arguments, void 0, function* ({ flowName, params }) {
        const app = (0, commonUtil_1.getCurApp)();
        const flowPath = (0, path_1.join)(app.APP_DIR, flowName + '.js');
        // console.log("子流程路径：" + flowPath);
        //判断流程是否存在
        if (!fs_1.default.existsSync(flowPath)) {
            throw new Error(`子流程${flowName}不存在`);
        }
        const flow = (0, commonUtil_1.flowModuleImport)(app.APP_DIR, flowName);
        console.log('调用子流程：' + flowName + '，参数：' + params);
        return yield flow({ _callParams: params });
    });
};
exports.impl = impl;
