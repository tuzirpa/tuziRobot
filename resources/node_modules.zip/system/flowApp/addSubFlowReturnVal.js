"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
exports.config = {
    name: 'flowApp.addSubFlowReturnVal',
    displayName: '子流程添加返回值',
    icon: 'icon-web-create',
    isControl: false,
    isControlEnd: false,
    comment: '添加返回值${val}到返回值列表中',
    inputs: {
        val: {
            name: 'val',
            value: '',
            type: 'array',
            addConfig: {
                label: '添加要返回的变量列表',
                placeholder: '请输入变量名,多个变量用英文逗号分隔, 可空',
                type: 'variable',
                multiple: true,
                // required: true,
                tip: '添加要返回的内容'
            }
        }
    },
    outputs: {},
    async toCode(directive, block) {
        const { val } = directive.inputs;
        return `await robotUtil.system.flowApp.addSubFlowReturnVal({val: [${val.value}] },_returnVal,${block})`;
    }
};
const impl = async function ({ val }, returnVal) {
    returnVal.push(...val);
};
exports.impl = impl;
