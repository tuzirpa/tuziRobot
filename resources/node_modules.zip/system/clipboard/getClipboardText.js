"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const hmc_win32_1 = __importDefault(require("hmc-win32"));
exports.config = {
    name: 'clipboard.getClipboardText',
    icon: 'icon-web-create',
    displayName: '读取剪贴板中的文本',
    comment: '读取剪贴板中的文本',
    inputs: {},
    outputs: {
        clipboardText: {
            name: '',
            display: '字符串-粘贴板文本内容',
            type: 'string',
            addConfig: {
                label: '粘贴板文本内容',
                type: 'variable',
                defaultValue: 'clipboardText'
            }
        }
    }
};
const impl = async function () {
    const clipboardText = hmc_win32_1.default.getClipboardText();
    return { clipboardText };
};
exports.impl = impl;
