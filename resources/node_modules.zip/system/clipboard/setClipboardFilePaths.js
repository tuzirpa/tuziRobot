"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const hmc_win32_1 = __importDefault(require("hmc-win32"));
exports.config = {
    name: 'clipboard.setClipboardFilePaths',
    icon: 'icon-web-create',
    displayName: '写入文件列表到剪贴板',
    comment: '写入文件列表${}到剪贴板',
    inputs: {
        filePaths: {
            name: 'filePaths',
            value: '',
            display: '',
            type: 'array',
            addConfig: {
                required: true,
                placeholder: '要写入剪贴板的文本内容',
                label: '文本内容',
                type: 'textarea',
                defaultValue: ''
            }
        }
    },
    outputs: {}
};
const impl = async function ({ filePaths }) {
    hmc_win32_1.default.setClipboardFilePaths(filePaths);
};
exports.impl = impl;
