"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const hmc_win32_1 = __importDefault(require("hmc-win32"));
exports.config = {
    name: 'clipboard.clearClipboard',
    icon: 'icon-web-create',
    displayName: '清空剪贴板',
    comment: '清空剪贴板',
    inputs: {},
    outputs: {}
};
const impl = async function () {
    hmc_win32_1.default.clearClipboard();
};
exports.impl = impl;
