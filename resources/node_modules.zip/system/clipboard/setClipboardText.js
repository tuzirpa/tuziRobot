"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const hmc_win32_1 = __importDefault(require("hmc-win32"));
exports.config = {
    name: 'clipboard.setClipboardText',
    icon: 'icon-web-create',
    displayName: '写入文本到剪贴板',
    comment: '写入文本${text}到剪贴板',
    inputs: {
        text: {
            name: 'text',
            value: '',
            display: '',
            type: 'string',
            addConfig: {
                required: true,
                placeholder: '要写入剪贴板的文本内容',
                label: '文本内容',
                type: 'textarea',
                defaultValue: ''
            }
        }
    },
    outputs: {}
};
const impl = async function ({ text }) {
    hmc_win32_1.default.setClipboardText(text);
};
exports.impl = impl;
