"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.impl = exports.config = void 0;
const hmc_win32_1 = __importDefault(require("hmc-win32"));
exports.config = {
    name: 'clipboard.getClipboardFilePaths',
    icon: 'icon-web-create',
    displayName: '读取剪贴板中的文件列表',
    comment: '读取剪贴板中的文件列表',
    inputs: {},
    outputs: {
        filePaths: {
            name: '',
            display: '文件路径列表-数组',
            type: 'array',
            addConfig: {
                label: '文件路径列表',
                type: 'variable',
                defaultValue: 'filePaths'
            }
        }
    }
};
const impl = async function () {
    const filePaths = hmc_win32_1.default.getClipboardFilePaths();
    return { filePaths };
};
exports.impl = impl;
